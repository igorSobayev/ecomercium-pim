<template>
  <section class="body">
    <h1>Esta es la home de la web, todavía esta en desarrollo</h1>
  </section>
</template>

<script>

export default {
  mounted() {},
  data() {
    return {
     
    };
  }
};
</script>

<style>
</style>

