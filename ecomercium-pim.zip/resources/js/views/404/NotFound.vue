<template>
    <section class="body pt-4">
        <h1>Not found</h1>
    </section>
</template>

<script>
export default {
    mounted() {},
    data() {
        return {};
    },
    methods: {}
};
</script>
