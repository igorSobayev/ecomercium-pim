<template>
  <section class="body d-flex justify-content-center row">
    <div class="col-lg-10 pb-4 pl-0">
      <h2>Listado de todas las tiendas y sus productos</h2>
    </div>
    <table class="table table-hover col-lg-10">
      <thead>
        <tr>
          <th scope="col">Tienda</th>
          <th scope="col">Nº Productos</th>
          <th scope="col">Stock total de productos</th>
          <th scope="col">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row">Amazon</th>
          <td>12</td>
          <td>134</td>
          <td>
            <b-dropdown text="Acciones" variant="outline-success">
              <b-dropdown-item href="#">Editar tienda </b-dropdown-item>
              <b-dropdown-item href="#">Gestionar productos tienda</b-dropdown-item>
              <b-dropdown-divider></b-dropdown-divider>
              <b-dropdown-item href="#">Eliminar tienda</b-dropdown-item>
            </b-dropdown>
          </td>
        </tr>
      </tbody>
    </table>
  </section>
</template>

<script>
export default {
  mounted() {},
  data() {
    return {};
  },
};
</script>

<style></style>
