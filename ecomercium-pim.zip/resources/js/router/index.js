import Vue from 'vue';
import Router from 'vue-router';

// Errores
import NotFound from './../views/404/NotFound'

// Home
import Home from './../views/Home'

// Productos
import Productos from './../views/productos/Productos'
import CrearEditarProducto from './../views/productos/CrearEditarProducto'

// Tiendas
import Tiendas from './../views/tiendas/Tiendas'

Vue.use(Router);

export default new Router({
    mode: 'history',
    base: '/',
    fallback: true,
    linkActiveClass: 'active',
    routes: [{
            path: '*',
            component: NotFound
        },
        // Home
        {
            path: '/',
            name: 'home',
            component: Home,
        },
        {
            path: '/productos',
            name: 'productos',
            component: Productos,
        },
        {
            path: '/productos/crear-producto',
            name: 'crear-producto',
            component: CrearEditarProducto,
        },
        {
            path: '/tiendas',
            name: 'tiendas',
            component: Tiendas,
        },
    ]
});
