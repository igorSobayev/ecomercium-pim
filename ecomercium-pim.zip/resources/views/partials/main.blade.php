{{-- Main --}}
<section role="main" class="content-body pb-0">
    <div class="container-fluid pt-5">
        <div id="app">
            <router-view></router-view>
        </div>
    </div>
</section>