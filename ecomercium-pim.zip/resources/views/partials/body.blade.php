<div class="container pt-4 pb-4">
 {{-- Contenido --}}
 @yield('content')
 {{-- Fin contenido --}}
</div>