@extends('layouts.app')

@section('content')
Empty -> se controla todo desde /resources/js
@endsection
