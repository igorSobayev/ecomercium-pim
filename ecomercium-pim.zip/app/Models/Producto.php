<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Producto extends Model
{
    use HasFactory;

    protected $table = 'pim_productos';
    protected $primaryKey = 'id_producto';

    protected $fillable = [
        'referencia', 'precio_sin_iva', 'precio_coste',
        'cantidad', 'producto_combinacion', 'activo',
        'ean13', 'marca'
    ];

    public function eliminarImgAsociadas(int $id_producto)
    {
        $imagenes_producto = ProductoImagen::select('id_producto', 'url_img', 'id_producto_img')->where('id_producto', $id_producto)->get();
        $fallo = false;
        foreach ($imagenes_producto as $img) {
            try {
                unlink(public_path() . $img->url_img);
                ProductoImagen::where('id_producto_img', $img->id_producto_img)->delete();
            } catch (\Exception $e) {
                $fallo = true;
                continue;
            }
        }
        return $fallo;
    }
}
