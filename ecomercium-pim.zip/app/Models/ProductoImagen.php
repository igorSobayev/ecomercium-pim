<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductoImagen extends Model
{
    use HasFactory;

    protected $table = 'pim_productos_img';
    protected $primaryKey = 'id_producto_img';

    protected $fillable = [
        'id_producto', 'url_img', 'img_principal'
    ];

}
