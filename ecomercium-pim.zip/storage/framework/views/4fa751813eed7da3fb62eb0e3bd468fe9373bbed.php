
<section role="main" class="content-body pb-0">
    <div class="container-fluid pt-5">
        <div id="app">
            <router-view></router-view>
        </div>
    </div>
</section><?php /**PATH C:\Users\isoba\Documents\VULPIT\ECOMERCIUM_PIM\ecomercium-pim\resources\views/partials/main.blade.php ENDPATH**/ ?>