<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title><?php echo e(config('app.name', 'Ecomercium PIM')); ?></title>

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome/css/all.min.css')); ?>" />

</head>

<body>


    
    <?php if(!Auth::check()): ?>
    <?php echo $__env->yieldContent('verification'); ?>
    
    <?php endif; ?>
    

    <?php if(Auth::check()): ?>
    <section class="body" id="app">

        <!-- start: header -->
        <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end: header -->

        <div class="inner-wrapper">

            
            <?php echo $__env->make('partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        </div>

    </section>
    <?php endif; ?>

    <?php if(Auth::check()): ?>
    
    <?php echo $__env->make('partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php endif; ?>

</body>

</html><?php /**PATH C:\Users\isoba\Documents\VULPIT\ECOMERCIUM_PIM\ecomercium-pim\resources\views/layouts/app.blade.php ENDPATH**/ ?>