<div class="container pt-4 pb-4">
 
 <?php echo $__env->yieldContent('content'); ?>
 
</div><?php /**PATH C:\Users\isoba\Documents\VULPIT\ECOMERCIUM_PIM\ecomercium-pim\resources\views/partials/body.blade.php ENDPATH**/ ?>