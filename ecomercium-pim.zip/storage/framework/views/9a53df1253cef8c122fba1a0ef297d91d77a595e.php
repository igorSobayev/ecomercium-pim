<?php $__env->startSection('content'); ?>
Empty -> se controla todo desde /resources/js
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\isoba\Documents\VULPIT\ECOMERCIUM_PIM\ecomercium-pim\resources\views/home.blade.php ENDPATH**/ ?>